importJS("TaskController-0.0.1");
importJS("RBM-0.0.3");
var Config = {
    fightType: 0, //0:地下城、塔 1:異界
    saleRune: false,
    getItemNum: 1,
    autoBuyFlash: true,
    appName: 'com.eason.SummonersWar',
    oriScreenWidth: 2560,
    oriScreenHeight: 1440,
    oriResizeFactor: 0.5,
    eventDelay: 500,
    resizeFactor: 0.5,
    imageThreshold: 0.9,
    imageQuality: 80,
    overFight: false,
    isRuning: false
};

function SummonersWarFight() {}
SummonersWarFight.prototype.click = function (image) {
    if (rbm.imageExists(image)) {
        rbm.imageClick(image);
        return true;
    }
    rbm.log('找不到圖片:' + image);
    return false;
}
SummonersWarFight.prototype.taskAutoStart = function () {
    if (Config.fightType == 3) {
        if (rbm.imageExists('readyFinish.png', 1)) {
            this.click('readyFinish.png')
            rbm.log('戰鬥準備');
            this.start();
            return;
        };
        if (this.click('startFight.png')) {
            rbm.log('戰鬥開始');
            rbm.imageWaitClick("buyFlashConfirm.png", 3000);
            rbm.log('是');
            this.start();
            return;
        }
        if (rbm.imageExists('need3member.png', 0.9)) {
            this.click('need3MemberApply.png');
            rbm.log('未滿三位隊員，確認');
            this.start();
            return;
        }
    } else {
        if (this.click('startButton.png')) {
            rbm.log('開始');
            this.start();
            return;
        }
    }
    //按完再來一次之後沒有體力，必須要購買
    if (rbm.imageExists('storeButton.png', 0.9) && Config.autoBuyFlash) {
        this.buyFlash();
        this.start();
        return;
    }

    if (Config.fightType == 3) {
        if (rbm.imageExists('useSameTeam.png', 0.9)) {
            this.click('buyFlashConfirm.png')
            rbm.log('再來一次');
            this.start();
            return;
        }
    } else {
        if (this.click('cancelRevival.png')) {
            rbm.log('取消復活');
            this.start();
            return;
        }
        if (this.click('playAgainFlash.png')) {
            rbm.log('再來一次');
            this.start();
            return;
        }
    }

    //    if (this.click("autoPlay.png")) {
    //        rbm.log('自動攻擊');
    //        return;
    //    }

    if (Config.fightType == 0) {
        if (this.click('victoryCrystal.png')) {
            rbm.log('戰鬥結束');
            rbm.imageWaitClick("box.png", 10000);
            rbm.log('點擊寶箱');
            if (!Config.saleRune) {
                for (i = 0; i < Config.getItemNum; i++) {
                    rbm.imageWaitClick("cancel.png", 10000);
                    rbm.log('取得道具');
                }
            } else {
                this.saleRune();
            }
            rbm.imageWaitClick('playAgainFlash.png', 10000);
            rbm.log('再來一次');
            rbm.sleep();
        }
    } else if (Config.fightType == 1) {
        if (this.click('dragonResult.png')) {
            rbm.log('戰鬥結束');
            rbm.imageWaitClick('dragonBox.png', 10000);
            rbm.log('點擊寶箱');
            if (!Config.saleRune) {
                for (i = 0; i < Config.getItemNum; i++) {
                    rbm.imageWaitClick('dragonCancel.png', 10000);
                    rbm.log('取得道具');
                }
            }
            rbm.imageWaitClick('playAgainFlash.png', 10000);
            rbm.log('再來一次');
            rbm.sleep();
        }
    } else if (Config.fightType == 2) {
        if (this.click('victoryCrystal.png')) {
            rbm.log('戰鬥結束');
            rbm.imageWaitClick('blackHoleBox.png', 10000);
            rbm.log('點擊寶箱');
            if (!Config.saleRune) {
                for (i = 0; i < Config.getItemNum; i++) {
                    rbm.imageWaitClick('cancel.png', 10000);
                    rbm.log('取得道具');
                }
            }
            rbm.imageWaitClick('blackHolePlayAgainFlash.png', 10000);
            rbm.log('再來一次');
            rbm.sleep();
        }
    } else if (Config.fightType == 3) {
        if (rbm.imageExists('team1st.png', 0.9)) {
            this.click('team1st.png')
            rbm.log('戰鬥結束');
            if (!Config.saleRune) {
                rbm.imageWaitClick('cancel.png', 2000);
                rbm.log('取得道具');
            }
            rbm.imageWaitClick('buyFlashConfirm.png', 2000);
            rbm.log('再來一次');
            rbm.sleep();
        }
    }
    this.start();
}

SummonersWarFight.prototype.taskAttack = function () {
    if (this.click("autoPlay.png")) {
        rbm.log('自動攻擊');
        return;
    }
}

SummonersWarFight.prototype.saleRune = function () {
    if (!rbm.imageExists("runeLv6.png", 0.8) && rbm.imageExists("saleRune.png")) {
        rbm.imageWaitClick("saleRune.png", 10000);
        rbm.log("售出道具");
        rbm.imageWaitClick('buyFlashConfirm.png', 10000);
        rbm.log('按下【是】');
    } else {
        rbm.imageWaitClick("cancel.png", 10000);
        rbm.log('6星符文或不可販售直接獲得');
    }
}

SummonersWarFight.prototype.buyFlash = function () {
    rbm.imageWaitClick('storeButton.png', 10000);
    rbm.log('按下商店');
    rbm.imageWaitClick('buyFlash.png', 10000);
    rbm.log('選擇30紅水補體');
    rbm.imageWaitClick('buyFlashConfirm.png', 10000);
    rbm.log('按下【是】');
    rbm.imageWaitClick('finishBuyAlertConfirm.png', 10000);
    rbm.log('按下【確認】');
    rbm.imageWaitClick('closeStore.png', 10000);
    rbm.log('關閉商店');
    rbm.imageWaitClick('playAgainFlash.png', 10000);
    rbm.log('再來一次');
}

SummonersWarFight.prototype.start = function () {
    if (Config.isRuning) {
        this.taskAutoStart();
    } else {
        rbm.log("stop");
    }
}

// ===================================================================================
var rbm;
var swf;
var gTaskController;

function stop() {
    console.log('【魔靈召喚】 停止');
    rbm.running = false;
    Config.isRuning = false;
    //    sleep(1000);
    //    if (gTaskController != undefined) {
    //        gTaskController.removeAllTasks();
    //    }
    //    if (gTaskController != undefined) {
    //        gTaskController.stop();
    //    }
    //    // rbm.oriScreencrop(Date.now()+'.png', 0, 0, 2560, 1440);
}

function start(fightType, saleRune, getItemNum, imageThreshold, autoBuyFlash) {
    console.log('【魔靈召喚】 啟動');
    Config.saleRune = saleRune;
    Config.fightType = fightType;
    Config.getItemNum = getItemNum;
    Config.imageThreshold = imageThreshold;
    Config.autoBuyFlash = autoBuyFlash;
    rbm = new RBM(Config);
    rbm.init();
    swf = new SummonersWarFight();
    Config.isRuning = true;
    swf.start();
    //    gTaskController = new TaskController();
    //    gTaskController.newTask('taskAutoStart', swf.taskAutoStart.bind(swf), 500, 0);
    //    // gTaskController.newTask('taskAttack', swf.taskAttack.bind(swf), 500, 0);
    //    sleep(1000);
    //    gTaskController.start();
    //    // rbm.oriScreencrop(Date.now()+'.png', 0, 0, 2560, 1440);
};

//start(0, true, 1, 0.9,true);
